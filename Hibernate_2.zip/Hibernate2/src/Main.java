import org.hibernate.*;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		
		try {
			tx = session.beginTransaction();
			Client c = new Client("lalilulelo");
			session.save(c);
			System.out.println(c);
			tx.commit();
		}
		catch(Exception ex) {
			tx.rollback();
			throw ex;
		}
		finally {
			session.close();
		}
	}

}
