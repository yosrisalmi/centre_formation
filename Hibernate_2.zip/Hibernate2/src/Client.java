import javax.persistence.*;

@Entity
@Table (name="CLIENT")
public class Client {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column (name="id")
	private int id;
	
	@Column(name="nom")
	private String nom;
	
	public Client(String nom) {
		this.nom = nom;
	}

	@Override
	public String toString() {
		return "Client [id=" + id + ", nom=" + nom + "]";
	}
}
