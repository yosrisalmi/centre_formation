import java.util.*;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
public class Commande {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int num;
	private Date date;
	
	@ManyToOne
	@Cascade(value = {CascadeType.SAVE_UPDATE})
	private Client client;
//	@MapKey(name="produit") ---> utilisé pour les Map
	public Commande(Client client) {
		this.date = new Date();
		this.client = client;
	}
	public Date getDate() {
		return date;
	}
	
	public void addProduit(Produit produit, int num) {
		
	}
	
	public void remove(Produit produit) {
		
	}
	
	public SortedSet<Produit> getProduit(){
		return null;
		
	}
	
	public int getQuantite(Produit produit) {
		return num;
		
	}
	
	public void delete() {
		
	}
	
	public void save() {
		
	}
}
