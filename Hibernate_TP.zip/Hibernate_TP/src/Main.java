import org.hibernate.*;

public class Main {

	public static void main(String[] args) {
		
		System.out.println('t' > 'W');
//		Session session = Passerelle.getSessionFactory().openSession();
//		Transaction tx = null;
//		
//		try {
//			tx = session.beginTransaction();
//			
//		
//			tx.commit();
//			
//		}
//		catch(Exception ex) {
//			tx.rollback();
//			throw ex;
//		}
//		finally {
//			session.close();
//		}
	}

}
