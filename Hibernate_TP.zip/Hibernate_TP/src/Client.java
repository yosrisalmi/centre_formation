import java.util.*;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.*;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name="CLIENT")
public class Client {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="nom")
	private String nom;
	
	@OneToMany(mappedBy = "client")
	@Cascade(value= { CascadeType.SAVE_UPDATE })
	@SortNatural
	private SortedSet<Commande> commandes = new TreeSet<>();
	
	@SuppressWarnings("unused")
	private Client() {
		
	}
	
	public Client(String nom) {
		this.nom = nom;
	}

	public String getNom() {
		return nom;
	}
	
	public Commande createCommande() {
		Commande commande = new Commande(this);
		commandes.add(commande);
		return commande;
	}
	
	public void remove(Commande commande) {
		commandes.remove(commande);
	}

	public void delete() {
		// Parcours de la liste pour supprimer les commandes
		for(Iterator<Commande> it = commandes.iterator() ; it.hasNext() ;) {
			Commande commande = it.next();
			it.remove();
			commande.delete();
		}
	}
	
	public SortedSet<Commande> getCommandes(){
		return Collections.unmodifiableSortedSet(commandes);
	}
	
	public void save() {
		
	}
	
	public String toString() {
		return this.nom + " : " + this.commandes.size();
	}
}
