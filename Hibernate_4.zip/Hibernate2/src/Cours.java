import javax.persistence.*;

@Entity
@Table (name="COURS")
public class Cours {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private int id;
	
	@Column(name="COURS")
	private String nomCours;
	
	@ManyToOne @JoinColumn(name="etudiantId")
	private Etudiant etudiant;
	public Cours() {
		
	}
	
	public Cours(Etudiant etu,String nomCours) {
		this.nomCours = nomCours;
		this.etudiant = etu;
		etu.addCours(this);
	}

	@Override
	public String toString() {
		return "Cours [id=" + id + ", nomCours=" + nomCours + ", etudiant=" + etudiant + "]";
	}
	
	
	
}
