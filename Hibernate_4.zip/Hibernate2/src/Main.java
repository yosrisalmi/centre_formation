import org.hibernate.*;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		
		try {
			tx = session.beginTransaction();
			Etudiant etudiant = new Etudiant("lalalla");
			Client c = new Client("lelele",etudiant);
			Cours cours = new Cours(etudiant, "Java");
			session.save(etudiant);
			session.save(cours);
			session.save(c);
			Client client = (Client)session.load(Client.class, 10);
			
			System.out.println(client.toString());
			System.out.println(client.getEtudiant());
			
			for(Object o : client.getEtudiant().getCours()) {
				System.out.println(o);
			}
			
//			tx.commit();
			
			System.out.println("listen");
		}
		catch(Exception ex) {
			tx.rollback();
			throw ex;
		}
		finally {
			session.close();
		}
	}

}
