import java.util.*;

import javax.persistence.*;

@Entity
@Table(name="ETUDIANT")
public class Etudiant {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	@Column(name="id")
	private int id;
	
	@Column(name="nom")
	private String nom;
	
	@OneToMany (mappedBy="etudiant")
	private Set<Cours> listeCours = new HashSet<Cours>();
	
	public Etudiant() {
		
	}
	
	public Etudiant(String nom) {
		this.nom = nom;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	@Override
	public String toString() {
		return "Etudiant [id=" + id + ", nom=" + nom + "]";
	}

	public void addCours(Cours cours) {
		listeCours.add(cours);
		
	}
	
	public Iterable<Cours> getCours(){
		return listeCours;
	}
	
	
}
