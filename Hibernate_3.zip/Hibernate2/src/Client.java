import javax.persistence.*;

@Entity
@Table (name="CLIENT")
public class Client {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column (name="id")
	private int id;
	
	@Column(name="nom")
	private String nom;
	
	@ManyToOne @JoinColumn(name="etudiantId")
	private Etudiant etudiant;
	
	public Client() {
		
	}
	
	public Client(String nom, Etudiant etu) {
		this.nom = nom;
		this.etudiant = etu;
		
	}

	@Override
	public String toString() {
		return "Client [id=" + id + ", nom=" + nom + "]";
	}
	
	public Etudiant getEtudiant() {
		return this.etudiant;
	}
}
