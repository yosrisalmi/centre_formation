package org.o7planning.springmvcshoppingcart.config;

public class WebMvcConfig {

}
