import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		//SessionFactory -> permet de créer une session
	
		//ajouter(new Client("", new Etudiant("")));
		Etudiant etu = new Etudiant("test_etu");
		
		Client client = new Client("test_client", etu);
		map(etu,client);
		afficher("from Client");
	} 
	
	public static void ajouter(Client etudiant) {
		Configuration cnf = new Configuration().configure("/hibernate.cfg.xml");
		SessionFactory sessionFactory = cnf.buildSessionFactory();
		Session session =sessionFactory.openSession(); //Ouvrir une nouvelle session
		Transaction tx = null; //Gerer les transactions
		 try {
				tx = session.beginTransaction();
				System.out.println("session save : "+(Integer)session.save(etudiant));
				tx.commit();
			}catch(Exception ex) {
				tx.rollback(); //Annuler la transaction en cas d'erreur
				throw ex;
			}finally {
				session.close(); //Fermer la session peu importe le résultat de la transaction
			}
	}
	
	public static void afficher(String query) {
		Configuration cnf = new Configuration().configure("/hibernate.cfg.xml");
		SessionFactory sessionFactory = cnf.buildSessionFactory();
		Session session =sessionFactory.openSession(); //Ouvrir une nouvelle session
	    session.beginTransaction();
	    @SuppressWarnings("rawtypes")
		List resultats = session.createQuery(query).list();
	    session.getTransaction().commit();
		System.out.println("Taille de la liste des objets récuperée : "+resultats.size());
		for (Object object : resultats) {
			Client c = (Client) object;
			if(c.getEtu() == null) {
				System.out.println("Etudiant vide");
			}else {
				System.out.println("récup donnée etudiant : |"+c.getEtu().getNom()+"|");
				System.out.println("récup donnée client : |"+c.getNom()+"|");
			}
		}
		session.close();
		
	}
	
	public static void map(Etudiant etu, Client client) {
		Configuration cnf = new Configuration().configure("/hibernate.cfg.xml");
		SessionFactory sessionFactory = cnf.buildSessionFactory();
		Session session =sessionFactory.openSession(); //Ouvrir une nouvelle session
		Transaction tx = null; //Gerer les transactions
		 try {
				tx = session.beginTransaction();
				client.setEtu(etu);
				session.save(etu);
				session.save(client);
				tx.commit();
			}catch(Exception ex) {
				tx.rollback(); //Annuler la transaction en cas d'erreur
				throw ex;
			}finally {
				session.close(); //Fermer la session peu importe le résultat de la transaction
			}
	}

}