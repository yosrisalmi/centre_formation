
public class Client {
	private int id;
	private String nom;
	private static int cpt = 0;
	private Etudiant etu;
	
	public Client() {
		
	}
	
	public Client(String nom, Etudiant etu) {
		this.etu = etu;
		this.nom = nom;
		this.id = cpt;
		cpt++;
	}
	
	public int getId() {
		return id;
	}
	
	
	public Etudiant getEtu() {
		return etu;
	}

	public void setEtu(Etudiant etu) {
		this.etu = etu;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}

	@Override
	public String toString() {
		return "Client [id=" + id + ", nom=" + nom + "] forme "+etu.toString();
	}
	
	
}
