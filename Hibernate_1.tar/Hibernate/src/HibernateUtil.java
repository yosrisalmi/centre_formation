import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
 
public class HibernateUtil {
    private static SessionFactory sessionFactory;
     
    static {
    	try {
    		Configuration conf = new Configuration();
    		conf.configure("hibernate.cfg.xml");
    		ServiceRegistry serviceReg = new StandardServiceRegistryBuilder().applySettings(conf.getProperties()).build();
    		sessionFactory = conf.buildSessionFactory(serviceReg);
    	} catch(Throwable ex){
    		System.err.println("Erreur !!");
    		throw new ExceptionInInitializerError(ex);
    	}
    }
    
    public static SessionFactory getSessionFactory() {
    	return sessionFactory;
    }
}